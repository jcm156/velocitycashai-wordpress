# VelocityCash AI - WordPress Site
## Sistema Completo de E-commerce y Blog para Consultoría de IA

---

## 📋 TABLA DE CONTENIDOS

1. [Descripción General](#descripción-general)
2. [Requisitos del Sistema](#requisitos-del-sistema)
3. [Estructura del Proyecto](#estructura-del-proyecto)
4. [Guía de Instalación](#guía-de-instalación)
5. [Configuración Post-Instalación](#configuración-post-instalación)
6. [Productos y Precios](#productos-y-precios)
7. [Integraciones](#integraciones)
8. [Optimización y Performance](#optimización-y-performance)
9. [Seguridad](#seguridad)
10. [Troubleshooting](#troubleshooting)

---

## 🎯 DESCRIPCIÓN GENERAL

Este es un sitio WordPress completo optimizado para conversión siguiendo los principios de Alex Hormozi's Value Equation:

- **Dream Outcome**: Posicionamiento como autoridad en generación de efectivo con IA
- **Perceived Likelihood**: Prueba social, casos de estudio, garantías claras
- **Time Delay**: Acceso instantáneo a productos, fulfillment automatizado
- **Effort & Sacrifice**: Compras con un clic, onboarding automatizado

### Características Principales:

✅ Blog optimizado para IA y conversión  
✅ WooCommerce con 4 productos listos  
✅ Páginas de ventas con value stacking  
✅ Integración completa con n8n para automatización  
✅ Sistema de analytics y tracking de conversiones  
✅ Email capture con lead magnets  
✅ Checkout optimizado con upsells  
✅ Sistema de webhooks para workflows automatizados  
✅ Performance optimizado (< 2 segundos de carga)  
✅ Security hardened desde el inicio  

---

## 💻 REQUISITOS DEL SISTEMA

### Servidor (SiteGround GrowBig):
- PHP 8.0 o superior
- MySQL 5.7 o superior
- Apache 2.4+ con mod_rewrite
- SSL Certificate (Let's Encrypt incluido en SiteGround)
- Memoria PHP: mínimo 256MB (recomendado 512MB)

### WordPress:
- WordPress 6.7+
- WooCommerce 8.0+
- Astra Pro Theme (o GeneratePress Premium)

### Integraciones Externas:
- n8n Cloud: `jcm156.app.n8n.cloud`
- Stripe (cuentas y API keys)
- PayPal (cuentas y API keys)
- Mailchimp (API key) - opcional

---

## 📁 ESTRUCTURA DEL PROYECTO

```
velocitycashai-wp/
├── wp-config.php                      # Configuración principal (EDITAR antes de usar)
├── .htaccess                          # Optimizaciones y seguridad
├── wp-content/
│   ├── themes/
│   │   └── velocitycash-child/
│   │       ├── style.css              # Estilos principales con sistema de diseño
│   │       ├── functions.php          # Funciones del tema, WooCommerce, n8n
│   │       ├── page-templates/
│   │       │   └── template-sales.php # Landing page de ventas Hormozi-style
│   │       └── assets/
│   │           ├── js/
│   │           │   └── custom.js      # Countdown, email capture, tracking
│   │           ├── css/
│   │           └── images/
│   └── plugins/
│       └── velocitycash-custom/
│           ├── velocitycash-custom.php     # Plugin principal
│           └── includes/
│               ├── class-analytics.php     # Tracking de eventos
│               ├── class-webhooks.php      # Integración n8n
│               └── class-conversions.php   # Optimización de conversión
└── README-DEPLOYMENT.md               # Este archivo
```

---

## 🚀 GUÍA DE INSTALACIÓN

### PASO 1: Preparar el Hosting en SiteGround

1. **Acceder al Site Tools de SiteGround**
   - Login en https://my.siteground.com
   - Click en "Site Tools" para velocitycashai.com

2. **Instalar WordPress**
   - Site Tools > WordPress > Install & Manage
   - Click "Install WordPress"
   - Configurar:
     * Domain: velocitycashai.com
     * Admin Email: tu@email.com
     * Admin Username: (elige un nombre seguro, NO "admin")
     * Admin Password: (genera una password fuerte)
   - Click "Install"

3. **Configurar SSL**
   - Site Tools > Security > SSL Manager
   - Seleccionar "Let's Encrypt"
   - Click "Install" (toma 5-10 minutos)
   - Activar "HTTPS Enforce"

### PASO 2: Instalar Tema Base (Astra)

1. **Login al WordPress Admin**
   - Ir a https://velocitycashai.com/wp-admin
   - User el username y password configurados en paso 1

2. **Instalar Astra Theme**
   - Apariencia > Temas > Añadir Nuevo
   - Buscar "Astra"
   - Instalar y Activar

3. **Subir Child Theme**
   - Comprimir la carpeta `velocitycash-child` en un ZIP
   - Apariencia > Temas > Añadir Nuevo > Subir Tema
   - Seleccionar el ZIP y subir
   - **ACTIVAR el child theme** (no el padre)

### PASO 3: Instalar Plugins Esenciales

**Plugins Obligatorios:**

1. **WooCommerce**
   - Plugins > Añadir Nuevo > buscar "WooCommerce"
   - Instalar y Activar
   - Seguir setup wizard (configurar país, moneda EUR, etc.)

2. **VelocityCash Custom Plugin**
   - Comprimir carpeta `velocitycash-custom` en ZIP
   - Plugins > Añadir Nuevo > Subir Plugin
   - Activar después de instalar

**Plugins Recomendados:**

3. **Wordfence Security** (seguridad)
4. **SG Optimizer** (caché de SiteGround - ya incluido)
5. **Yoast SEO** o **Rank Math** (SEO)
6. **Contact Form 7** (formularios)
7. **UpdraftPlus** (backups automáticos)

### PASO 4: Configurar wp-config.php

1. **Conectar por FTP/SFTP**
   - Host: velocitycashai.com
   - Username: (tu usuario SiteGround)
   - Password: (tu password SiteGround)
   - Port: 21 (FTP) o 22 (SFTP)

2. **Editar wp-config.php**
   ```php
   // Cambiar estas líneas:
   define('DB_NAME', 'nombre_real_de_tu_base_datos');
   define('DB_USER', 'usuario_real_mysql');
   define('DB_PASSWORD', 'password_real_mysql');
   ```

3. **Generar Authentication Keys**
   - Ir a https://api.wordpress.org/secret-key/1.1/salt/
   - Copiar TODAS las keys generadas
   - Reemplazar las líneas de AUTH_KEY, SECURE_AUTH_KEY, etc.

4. **Cambiar Table Prefix**
   ```php
   $table_prefix = 'vc_abc123_'; // usar algo único
   ```

5. **Subir .htaccess**
   - Subir el archivo `.htaccess` a la raíz del sitio
   - Verificar que funcione (el sitio debe cargar normal)

### PASO 5: Configurar WooCommerce

1. **Configuración General**
   - WooCommerce > Ajustes > General
   - Dirección de la tienda: España
   - Moneda: EUR (€)
   - Posición del símbolo de moneda: Izquierda con espacio

2. **Configurar Pasarelas de Pago**
   
   **Stripe:**
   - WooCommerce > Ajustes > Pagos
   - Activar Stripe
   - Click "Gestionar"
   - Introducir:
     * Publishable Key (de tu cuenta Stripe)
     * Secret Key (de tu cuenta Stripe)
   - Activar modo test primero

   **PayPal:**
   - WooCommerce > Ajustes > Pagos
   - Activar PayPal
   - Introducir email de PayPal

3. **Configurar Impuestos**
   - WooCommerce > Ajustes > Impuestos
   - Activar impuestos
   - Configurar IVA estándar (21% en España)

4. **Configurar Envío**
   - Para productos digitales: desactivar shipping
   - WooCommerce > Ajustes > Envío
   - Eliminar zonas de envío

### PASO 6: Crear Productos

**Crear los 4 productos principales:**

#### Producto 1: AI Cash Accelerator Elite (€997)

1. Productos > Añadir Nuevo
2. Título: "AI Cash Accelerator Elite"
3. Descripción: [Ver sección de Productos más abajo]
4. Precio normal: 997
5. Producto virtual: ✓
6. Producto descargable: ✓
7. Categoría: Consultoría Premium
8. En la pestaña "VelocityCash Custom":
   - Value Stack (JSON):
   ```json
   [
     {"name":"Consultoría 1-on-1 (6 sesiones)","value":2997},
     {"name":"Implementación Completa","value":1997},
     {"name":"Soporte Prioritario 90 Días","value":1497},
     {"name":"50 Prompts Premium ChatGPT","value":297},
     {"name":"n8n Workflow Templates","value":497},
     {"name":"AI Tools Directory","value":197},
     {"name":"Actualizaciones 1 año","value":1200},
     {"name":"Private Slack Community","value":497},
     {"name":"Monthly Expert Webinars","value":997}
   ]
   ```
   - Mostrar Timer de Urgencia: ✓
   - Texto de Escasez: "⚠️ Solo quedan 3 plazas este mes"
   - Mostrar Garantía 90 Días: ✓

#### Producto 2: AI Automation Toolkit Pro (€297)

1. Productos > Añadir Nuevo
2. Título: "AI Automation Toolkit Pro"
3. Precio: 297
4. Value Stack:
   ```json
   [
     {"name":"15 Automatizaciones Listas","value":1497},
     {"name":"Templates n8n Pro","value":497},
     {"name":"Training Videos (10 horas)","value":397},
     {"name":"50 Prompts Premium","value":297},
     {"name":"Soporte Email 60 Días","value":297},
     {"name":"Actualizaciones Lifetime","value":597}
   ]
   ```
5. Mostrar Timer: ✓
6. Mostrar Garantía: ✓

#### Producto 3: AI Fundamentals Bootcamp (€47)

1. Productos > Añadir Nuevo
2. Título: "AI Fundamentals Bootcamp"
3. Precio: 47
4. Value Stack:
   ```json
   [
     {"name":"Curso 5 Módulos","value":197},
     {"name":"Certificado de Completion","value":97},
     {"name":"Acceso Comunidad Discord","value":147},
     {"name":"10 Prompts Esenciales","value":47}
   ]
   ```

#### Producto 4: AI Inner Circle (€97/mes)

1. Productos > Añadir Nuevo
2. Título: "AI Inner Circle - Membership"
3. Precio: 97 cada mes
4. Tipo: Suscripción Simple (necesita plugin WooCommerce Subscriptions)
5. Periodo de facturación: Mensual
6. Value Stack:
   ```json
   [
     {"name":"Masterminds Mensuales","value":297},
     {"name":"Updates Constantes","value":147},
     {"name":"Q&A Sessions Semanales","value":497},
     {"name":"Acceso Contenido Premium","value":197},
     {"name":"Descuentos en Otros Productos","value":100}
   ]
   ```

### PASO 7: Crear Páginas Importantes

**1. Homepage**
- Páginas > Añadir Nueva
- Título: "Home"
- Ajustes > Lectura > Página principal: seleccionar "Home"
- Usar page builder (Elementor/Beaver Builder) o shortcodes

**2. Página de Ventas Principal**
- Páginas > Añadir Nueva
- Título: "Transforma Tu Negocio con IA"
- Template: Página de Ventas (el que creamos)
- Este template ya tiene todo el contenido Hormozi-style

**3. Blog**
- Páginas > Añadir Nueva
- Título: "Blog"
- Ajustes > Lectura > Página de entradas: seleccionar "Blog"

**4. Sobre Nosotros**
- Información de la empresa
- Equipo
- Misión y valores

**5. Contacto**
- Usar Contact Form 7
- Incluir shortcode: `[vc_email_form type="contact"]`

**6. Política de Privacidad**
- Ajustes > Privacidad > Crear página automática
- Revisar y personalizar

**7. Términos y Condiciones**
- Especialmente importante para e-commerce
- Incluir política de devoluciones

### PASO 8: Configurar Menu de Navegación

1. Apariencia > Menús
2. Crear nuevo menú: "Primary Menu"
3. Agregar páginas:
   - Inicio
   - Productos (link a /tienda/)
   - Blog
   - Casos de Éxito
   - Contacto
4. Asignar a ubicación: "Primary Menu"

### PASO 9: Configurar Widgets

1. **Sidebar Blog:**
   - `[vc_email_form type="sidebar"]`
   - Posts recientes
   - Categorías

2. **Footer:**
   - Footer 1: Sobre nosotros + logo
   - Footer 2: Links rápidos
   - Footer 3: Contacto + redes sociales

---

## ⚙️ CONFIGURACIÓN POST-INSTALACIÓN

### Configurar VelocityCash Analytics

1. **Ir a Dashboard > VC Analytics > Configuración**

2. **Configurar n8n:**
   ```
   n8n Webhook URL: https://jcm156.app.n8n.cloud/webhook/
   ```

3. **Configurar Mailchimp (opcional):**
   ```
   Mailchimp API Key: [tu API key aquí]
   ```

4. **Configurar Stripe:**
   ```
   Stripe Public Key: pk_live_xxxxx
   Stripe Secret Key: sk_live_xxxxx
   ```
   Empezar en modo test:
   ```
   pk_test_xxxxx
   sk_test_xxxxx
   ```

### Crear Workflows en n8n

Los webhooks del sitio enviarán datos automáticamente a estos endpoints:

1. **`/webhook/order-completed`**
   - Trigger: Pedido completado
   - Acciones sugeridas:
     * Enviar email de bienvenida
     * Crear cliente en CRM
     * Enviar acceso a productos
     * Notificar en Slack

2. **`/webhook/user-registered`**
   - Trigger: Nuevo usuario registrado
   - Acciones:
     * Email de bienvenida
     * Agregar a lista de Mailchimp
     * Crear perfil en CRM

3. **`/webhook/lead-capture`**
   - Trigger: Captura de email
   - Acciones:
     * Enviar lead magnet
     * Iniciar secuencia de nurture
     * Notificación interna

4. **`/webhook/contact-form`**
   - Trigger: Envío de formulario de contacto
   - Acciones:
     * Crear ticket
     * Notificar equipo
     * Respuesta automática

### Configurar Google Analytics 4

1. Crear propiedad en Google Analytics
2. Obtener Measurement ID (G-XXXXXXXXXX)
3. Agregar a header.php o usar plugin:
   ```html
   <!-- Google tag (gtag.js) -->
   <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
   <script>
     window.dataLayer = window.dataLayer || [];
     function gtag(){dataLayer.push(arguments);}
     gtag('js', new Date());
     gtag('config', 'G-XXXXXXXXXX');
   </script>
   ```

### Configurar Facebook Pixel

1. Crear pixel en Facebook Business Manager
2. Copiar Pixel ID
3. Agregar código en header o usar plugin

---

## 💰 PRODUCTOS Y PRECIOS

### Estructura de Value Stacking Hormozi

Cada producto muestra:
1. **Valor Total** de todos los componentes
2. **Tu Inversión HOY** (el precio real)
3. **Ahorro** = Valor Total - Precio

Ejemplo real del AI Cash Accelerator Elite:

| Componente | Valor |
|------------|-------|
| Consultoría 1-on-1 (6 sesiones) | €2,997 |
| Implementación Completa | €1,997 |
| Soporte Prioritario 90 Días | €1,497 |
| 50 Prompts Premium ChatGPT | €297 |
| n8n Workflow Templates | €497 |
| AI Tools Directory | €197 |
| Actualizaciones 1 año | €1,200 |
| Private Slack Community | €497 |
| Monthly Expert Webinars | €997 |
| **VALOR TOTAL** | **€10,176** |
| **TU INVERSIÓN HOY** | **€997** |
| **AHORRAS** | **€9,179 (90%)** |

---

## 🔗 INTEGRACIONES

### n8n Webhooks

El sitio envía automáticamente datos a n8n en estos eventos:

**Eventos de E-commerce:**
- `order-completed` - Pedido completado
- `order-processing` - Pedido en proceso
- `order-failed` - Pedido fallido

**Eventos de Usuario:**
- `user-registered` - Nuevo registro
- `user-login` - Login de usuario

**Eventos de Marketing:**
- `lead-capture` - Captura de email
- `contact-form` - Envío de formulario
- `exit-intent` - Intento de salida

**Payload Example:**
```json
{
  "event": "order-completed",
  "order_id": 123,
  "customer": {
    "email": "cliente@email.com",
    "first_name": "Juan",
    "last_name": "Pérez"
  },
  "items": [...],
  "totals": {
    "total": 997.00
  }
}
```

### Stripe

**Test Mode:**
```
Publishable: pk_test_51xxxxx
Secret: sk_test_51xxxxx
```

**Live Mode:**
```
Publishable: pk_live_51xxxxx
Secret: sk_live_51xxxxx
```

**Tarjetas de prueba:**
- Éxito: 4242 4242 4242 4242
- Fallo: 4000 0000 0000 0002
- 3D Secure: 4000 0027 6000 3184

### PayPal

Configurar en WooCommerce > Ajustes > Pagos > PayPal

---

## 🚀 OPTIMIZACIÓN Y PERFORMANCE

### Objetivos de Performance:
- ✅ First Contentful Paint < 1.5s
- ✅ Largest Contentful Paint < 2.5s
- ✅ Total Blocking Time < 300ms
- ✅ Cumulative Layout Shift < 0.1
- ✅ Speed Index < 3.4s

### Activar Caché en SiteGround:

1. **Site Tools > Speed > Caching**
   - Static Cache: ON
   - Dynamic Cache: ON
   - Memcached: ON

2. **SG Optimizer Plugin**
   - Environment Optimization > Activar todo
   - Frontend Optimization > Minify CSS/JS
   - Lazy Load: Activar

### Optimizar Imágenes:

1. **Instalar Smush Plugin**
2. **Configurar:**
   - Compression: Lossy
   - Lazy Load: Activado
   - WebP: Activado (si disponible)

### CDN (Opcional - Cloudflare):

1. Crear cuenta en Cloudflare
2. Cambiar nameservers en SiteGround
3. Configurar SSL en Cloudflare (Full)
4. Activar Auto Minify
5. Activar Brotli

### Monitorear Performance:

Herramientas:
- Google PageSpeed Insights
- GTmetrix
- WebPageTest
- Chrome DevTools

---

## 🔒 SEGURIDAD

### Checklist de Seguridad:

- [ ] SSL Activado y forzado (HTTPS)
- [ ] WordPress actualizado a última versión
- [ ] Plugins actualizados
- [ ] Tema actualizado
- [ ] Wordfence instalado y configurado
- [ ] Login URL cambiada (con plugin)
- [ ] Límite de intentos de login
- [ ] 2FA activado para admin
- [ ] Backups automáticos configurados
- [ ] wp-config.php protegido
- [ ] .htaccess con reglas de seguridad
- [ ] PHP versión 8.0+
- [ ] Database prefix cambiado
- [ ] Admin username NO es "admin"
- [ ] Passwords fuertes en todo
- [ ] File permissions correctos (644/755)

### Configurar Wordfence:

1. **Firewall:**
   - Activar Web Application Firewall
   - Modo: Learning (primeros 7 días), luego Enabled

2. **Scan:**
   - Scan automático diario
   - Email notificaciones: Activado

3. **Login Security:**
   - Activar 2FA para admin
   - Limitar intentos de login: 5 por hora
   - Bloquear IPs con intentos fallidos

### Backups Automáticos:

**Con UpdraftPlus:**
1. Instalar UpdraftPlus
2. Configurar:
   - Frecuencia: Diario
   - Retención: 7 días
   - Remoto: Google Drive / Dropbox
3. Hacer backup manual antes de cambios importantes

**Backup de SiteGround:**
- Site Tools > Security > Backups
- Crear backup manual antes de updates

---

## 🐛 TROUBLESHOOTING

### El sitio muestra "Error establishing a database connection"

**Solución:**
1. Verificar credenciales en wp-config.php
2. Verificar que MySQL esté corriendo
3. Contactar soporte SiteGround

### El sitio está en blanco después de activar plugin/theme

**Solución:**
1. Conectar por FTP
2. Renombrar carpeta del plugin/theme problemático
3. Acceder al admin y desactivar/eliminar

### Los productos no se muestran

**Solución:**
1. WooCommerce > Estado > Tools
2. Click "Regenerar páginas de tienda"
3. Verificar permalinks: Ajustes > Enlaces Permanentes > Guardar

### El .htaccess causa error 500

**Solución:**
1. Renombrar .htaccess a .htaccess.bak via FTP
2. Crear nuevo .htaccess con solo reglas de WordPress
3. Agregar reglas personalizadas una por una para identificar problema

### Las imágenes no cargan después de migrar

**Solución:**
1. Regenerar miniaturas: Herramientas > Regenerate Thumbnails
2. Verificar permisos de wp-content/uploads: 755

### Los emails no se envían

**Solución:**
1. Instalar WP Mail SMTP plugin
2. Configurar con credentials de:
   - Gmail
   - SendGrid
   - O el SMTP de SiteGround

### El sitio está lento

**Diagnóstico:**
1. Desactivar todos los plugins
2. Activar uno por uno identificando el problema
3. Verificar:
   - Query Monitor plugin
   - Database queries
   - External API calls

**Soluciones comunes:**
- Actualizar a PHP 8.0+
- Activar Object Cache
- Optimizar database
- Reducir plugins

---

## 📞 SOPORTE

### Soporte SiteGround:
- https://my.siteground.com/support
- Chat 24/7 disponible
- Teléfono: +34 931 222 171

### Recursos Útiles:
- WordPress Codex: https://codex.wordpress.org/
- WooCommerce Docs: https://woocommerce.com/documentation/
- n8n Documentation: https://docs.n8n.io/

### Community:
- WordPress Forum: https://wordpress.org/support/
- WooCommerce Forum: https://woocommerce.com/community-forum/
- n8n Community: https://community.n8n.io/

---

## ✅ CHECKLIST FINAL ANTES DE LAUNCH

### Pre-Launch:

- [ ] SSL activado y verificado
- [ ] Todos los productos creados y configurados
- [ ] Pasarelas de pago en modo LIVE
- [ ] Emails de confirmación funcionando
- [ ] Formularios de contacto probados
- [ ] Analytics configurado
- [ ] Facebook Pixel configurado
- [ ] n8n webhooks probados
- [ ] Backups automáticos configurados
- [ ] Sitemap enviado a Google Search Console
- [ ] Robots.txt configurado
- [ ] 404 page personalizada
- [ ] Todos los links internos funcionando
- [ ] Tested en mobile/tablet/desktop
- [ ] Tested en Chrome/Firefox/Safari
- [ ] Performance score > 80 en PageSpeed
- [ ] Política de privacidad publicada
- [ ] Términos y condiciones publicados
- [ ] Política de devoluciones clara
- [ ] Logo y favicon configurados
- [ ] Social media links añadidos
- [ ] Email signature configurado

### Post-Launch:

- [ ] Monitorear analytics primeros 7 días
- [ ] Verificar conversiones funcionan
- [ ] Revisar logs de errores
- [ ] Verificar webhooks en n8n
- [ ] Hacer test purchase completo
- [ ] Verificar emails automáticos
- [ ] Monitorear velocidad del sitio
- [ ] Configurar alertas de uptime
- [ ] Crear backup post-launch

---

## 📈 PRÓXIMOS PASOS

1. **Marketing:**
   - Configurar Google Ads
   - Crear campañas Facebook Ads
   - Content marketing en blog
   - Email marketing sequences

2. **Optimización:**
   - A/B testing de landing pages
   - Optimizar funnel de conversión
   - Mejorar copy basado en analytics
   - Test diferentes precios/ofertas

3. **Escalamiento:**
   - Agregar más productos
   - Crear membresía avanzada
   - Webinars automatizados
   - Curso online completo

---

**🎉 ¡Felicidades! Tu sitio está listo para generar ingresos con IA.**

Para cualquier duda durante el setup, documenta el error exacto y contáctame con screenshots.