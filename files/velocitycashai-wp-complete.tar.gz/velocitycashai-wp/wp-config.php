<?php
/**
 * VelocityCash AI - WordPress Configuration
 * Hardened for security and optimized for performance
 * 
 * IMPORTANTE: Cambia TODOS los valores de seguridad antes de deployment
 */

// ============================================================================
// DATABASE CONFIGURATION
// ============================================================================
define('DB_NAME', 'tu_nombre_base_datos');
define('DB_USER', 'tu_usuario_mysql');
define('DB_PASSWORD', 'tu_password_mysql_seguro');
define('DB_HOST', 'localhost'); // SiteGround normalmente usa localhost
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

// ============================================================================
// AUTHENTICATION UNIQUE KEYS AND SALTS
// ============================================================================
// CRÍTICO: Genera nuevas keys en https://api.wordpress.org/secret-key/1.1/salt/
define('AUTH_KEY',         'pon-tu-key-unica-aqui-generada-en-wordpress-org');
define('SECURE_AUTH_KEY',  'pon-tu-key-unica-aqui-generada-en-wordpress-org');
define('LOGGED_IN_KEY',    'pon-tu-key-unica-aqui-generada-en-wordpress-org');
define('NONCE_KEY',        'pon-tu-key-unica-aqui-generada-en-wordpress-org');
define('AUTH_SALT',        'pon-tu-key-unica-aqui-generada-en-wordpress-org');
define('SECURE_AUTH_SALT', 'pon-tu-key-unica-aqui-generada-en-wordpress-org');
define('LOGGED_IN_SALT',   'pon-tu-key-unica-aqui-generada-en-wordpress-org');
define('NONCE_SALT',       'pon-tu-key-unica-aqui-generada-en-wordpress-org');

// ============================================================================
// WORDPRESS DATABASE TABLE PREFIX
// ============================================================================
$table_prefix = 'vc_'; // Cambiar el prefijo por defecto mejora la seguridad

// ============================================================================
// SECURITY HARDENING
// ============================================================================

// Deshabilitar edición de archivos desde el admin
define('DISALLOW_FILE_EDIT', true);

// Forzar SSL en admin y login
define('FORCE_SSL_ADMIN', true);

// Deshabilitar instalación de plugins/themes sin autorización
define('DISALLOW_FILE_MODS', false); // Cambiar a true después de setup inicial

// Aumentar límite de memoria de WordPress
define('WP_MEMORY_LIMIT', '256M');
define('WP_MAX_MEMORY_LIMIT', '512M');

// Limitar revisiones de posts para ahorrar espacio
define('WP_POST_REVISIONS', 5);

// Configurar autosave interval (segundos)
define('AUTOSAVE_INTERVAL', 300); // 5 minutos

// Configurar empty trash (días)
define('EMPTY_TRASH_DAYS', 30);

// Deshabilitar actualizaciones automáticas del core (gestionar manualmente)
define('AUTOMATIC_UPDATER_DISABLED', false);
define('WP_AUTO_UPDATE_CORE', 'minor'); // solo updates de seguridad

// ============================================================================
// PERFORMANCE OPTIMIZATION
// ============================================================================

// Enable WP Cron (SiteGround tiene system cron, pero dejamos esto por si acaso)
define('DISABLE_WP_CRON', false);

// Increase PHP execution time
@ini_set('max_execution_time', 300);

// Enable WP Cache (si no usas plugin de cache)
define('WP_CACHE', true);

// Concatenate admin scripts
define('CONCATENATE_SCRIPTS', true);

// Compress JavaScript and CSS
define('COMPRESS_CSS', true);
define('COMPRESS_SCRIPTS', true);
define('ENFORCE_GZIP', true);

// ============================================================================
// DEBUGGING (DESHABILITAR EN PRODUCCIÓN)
// ============================================================================

// Cambiar a false en producción
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', false);
define('WP_DEBUG_DISPLAY', false);
@ini_set('display_errors', 0);

// Script Debug (solo en desarrollo)
define('SCRIPT_DEBUG', false);

// Guardar queries para análisis (solo en desarrollo)
define('SAVEQUERIES', false);

// ============================================================================
// SSL CONFIGURATION
// ============================================================================

// Si estás detrás de un proxy (como Cloudflare)
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $_SERVER['HTTPS'] = 'on';
}

// ============================================================================
// CUSTOM PATHS (opcional)
// ============================================================================

// define('WP_CONTENT_DIR', dirname(__FILE__) . '/wp-content');
// define('WP_CONTENT_URL', 'https://velocitycashai.com/wp-content');
// define('WP_PLUGIN_DIR', dirname(__FILE__) . '/wp-content/plugins');
// define('WP_PLUGIN_URL', 'https://velocitycashai.com/wp-content/plugins');

// ============================================================================
// MULTISITE (si decides usar en el futuro)
// ============================================================================

// define('WP_ALLOW_MULTISITE', true);

// ============================================================================
// FTP CONFIGURATION (si es necesario para updates)
// ============================================================================

// define('FS_METHOD', 'direct'); // SiteGround normalmente no necesita esto

// ============================================================================
// CLOUDFLARE CONFIGURATION
// ============================================================================

// Si usas Cloudflare, agregar sus IPs a trusted proxies
if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
    $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];
}

// ============================================================================
// WOOCOMMERCE SPECIFIC
// ============================================================================

// Aumentar timeout de sesiones de WooCommerce
define('WC_SESSION_CACHE_GROUP', 'wc_session_id');

// ============================================================================
// LOAD WORDPRESS
// ============================================================================

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}

require_once ABSPATH . 'wp-settings.php';

// ============================================================================
// NOTAS DE DEPLOYMENT
// ============================================================================

/*
ANTES DE SUBIR A PRODUCCIÓN:

1. Cambiar TODAS las database credentials
2. Generar nuevas AUTH_KEYS en https://api.wordpress.org/secret-key/1.1/salt/
3. Cambiar WP_DEBUG a false
4. Cambiar table_prefix de 'vc_' a algo único
5. Configurar SSL certificate en SiteGround
6. Activar Cloudflare (opcional pero recomendado)
7. Configurar backups automáticos en SiteGround
8. Instalar plugin de seguridad (Wordfence o similar)
9. Configurar firewall en SiteGround
10. Habilitar caché en SiteGround

PLUGINS RECOMENDADOS PARA INSTALAR:

SEGURIDAD:
- Wordfence Security
- iThemes Security

PERFORMANCE:
- SG Optimizer (de SiteGround, incluido gratis)
- WP Rocket (opcional, de pago)
- Smush (optimización de imágenes)

BACKUP:
- UpdraftPlus (backups automáticos)

SEO:
- Yoast SEO o Rank Math

FORMS:
- Contact Form 7 o WPForms
*/